import React from "react";

const SearchFilter = () => {
  return <div></div>;
};

export default SearchFilter;
